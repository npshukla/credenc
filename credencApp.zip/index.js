import { AppRegistry } from 'react-native';
import App from './App';
global.serverUrl = 'http://192.168.0.175';
AppRegistry.registerComponent('credencApp', () => App);
