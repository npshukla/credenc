<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//5000  , 9711691451

DEMUX ISSUE :
    
    1. REMOVE Build directory in  android and android/app , run clean and run react-native run-android then create release
 









TO DO:
    
    https://github.com/jondot/awesome-react-native

    https://github.com/rhaker/react-native-sms-android
    
    https://github.com/LynxITDigital/react-native-contacts-wrapper

    http://nsimage.brosteins.com/
    

https://github.com/facebook/jest

http://romannurik.github.io/AndroidAssetStudio/icons-launcher.html#foreground.type=image&foreground.space.trim=1&foreground.space.pad=0.15&foreColor=rgba(96%2C%20125%2C%20139%2C%200)&backColor=rgb(255%2C%20255%2C%20255)&crop=0&backgroundShape=square&effects=none&name=ic_launcher


        
        npm uninstall --save-dev
        
        

https://facebook.github.io/react-native/docs/getting-started.html
    
Install native base 
install react nativation (https://www.npmjs.com/package/react-navigation) 
  react-native-linkedin
    npm install react-native-easy-grid --save
    
    npm i react-native-autocomplete-select
    
    npm install react-native-communications
    
    npm install --save react-native-oauth
   
    https://github.com/magus/react-native-facebook-login
    
    https://github.com/devfd/react-native-google-signin
    
    
    
   react-native bundle --platform android --dev false --entry-file index.js --bundle-output android/app/src/main/assets/index.android.bundle --assets-dest android/app/src/main/res
    
    
    
    
issue: 
       https://stackoverflow.com/questions/44446523/unable-to-load-script-from-assets-index-android-bundle-on-windows
    
    
    https://stackoverflow.com/questions/44071080/could-not-find-com-android-tools-buildgradle3-0-0-alpha1-in-circle-ci
    
    https://stackoverflow.com/questions/44446523/unable-to-load-script-from-assets-index-android-bundle-on-windows
    
    
    https://github.com/react-navigation/react-navigation/issues/3148
    
    https://github.com/fullstackreact/react-native-oauth/pull/181/commits
    
    https://github.com/facebook/react-native/issues/5787
    
    https://stackoverflow.com/questions/34218249/android-studio-aapt-err-libpng-error-not-a-png-file/37318560
    
    https://github.com/facebook/react-native/issues/5787
    
   
    install imagemagick https://www.imagemagick.org/script/index.php and run

magick mogrify *.png
in problem image folder.

        
        https://github.com/magus/react-native-facebook-login/issues/233
    
    GOOGLE SIGNIN:
    
    
    https://github.com/devfd/react-native-google-signin/issues/268
    
    APP HASHKEY:

    https://developers.facebook.com/docs/android/getting-started/#release-key-hash
    
    









