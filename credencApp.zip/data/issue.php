<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

1. COnditional Image Load
2. check app request location and return 
3. College Search , profile    profile done
4. Cutomer image not showing   done 
5.  what if contact no changed
6. contact no mandatory
7. Back button handle , ask for exit
8. Fetch all data
9. drop down configuration and design    
    
    
    