<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

google 

project id :  api-project-45651595322 
    
  SERVER KEY:
    
    AAAACqEMEDo:APA91bGIAFFaCcnozIOnurIXIgDuze082LEof36_dc88RVS4enzapvqOFOqQiGO1YJepneGAD5bnbKbh3aLJCJV9W1ElXafd-OhxazgGUouAkaNFYGn48kLB0T2DYeiJbTp6BfyDCqy9
    
    
    SENDER KEY:
    
    45651595322