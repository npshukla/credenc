const React = require("react-native");
//import Exponent from 'expo';
const { StyleSheet } = React;

export default {
  container: {
    backgroundColor: "#fff",
   // marginTop: Exponent.Constants.statusBarHeight
  }
  
  
};